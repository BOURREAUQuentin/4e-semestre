import java.util.ArrayList;
import java.util.List;

abstract class Observable {
  private List<IObservateur> observateurs = new ArrayList<IObservateur>();

  public void addObservateur(IObservateur observateur) {
    this.observateurs.add(observateur);
  }

  public void notifierObservateurs(String info) {
    for (IObservateur observateur : observateurs) {
      observateur.notification(info);
    }
  }
}
