import javax.swing.*;

public class Terminal extends JFrame implements IObservateur {
  private JLabel message;

  public Terminal(String titre){
    this.setTitle(titre);
    this.setSize(300, 200);
    message = new JLabel("Compte ok!");
    this.add(message);
    this.setVisible(true);
  }

  @Override
  public void notification(String info) {
    this.message.setText(info);
  }
}
