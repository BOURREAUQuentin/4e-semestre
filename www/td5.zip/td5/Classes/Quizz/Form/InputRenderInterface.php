<?php
declare(strict_types=1);

namespace Quizz\Form;

interface InputRenderInterface
{
    public function render();
}