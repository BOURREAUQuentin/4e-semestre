
interface IObservateur {
  void notification(String message) ;

}
